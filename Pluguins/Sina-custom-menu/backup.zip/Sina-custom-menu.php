<?php
/*
Plugin Name: Sina Custom Menu
Description: Automatically builds a hierarchical menu from categories.
Version: 1.0
Author: Sina Sotoudeh
*/
/*
 *منووووووو
 * @return array
 */
//  تابع پاک کننده ی کش منو
 add_action('init', function(){
  if ( current_user_can('manage_options') ) {
    delete_transient('cmenu_tree');
    error_log('[CMENU DEBUG] transient cmenu_tree deleted');
  }
});


function cmenu_build_full_tree() {
    $taxonomy = 'category';
    $exclude  = [1,54,55];  // در صورت نیاز
    $tree = [];
    // 1. دسته‌های ریشه ( parent = 0 )
    $roots = get_terms([
        'taxonomy'        => $taxonomy,
        'hide_empty'      => false,
        'parent'          => 0,
        'exclude'         => $exclude,
        'hierarchical'    => false,
    ]);
    
    if ( is_wp_error($roots) ) {
        return $tree;
    }
    
    // ۲. تعیین ترتیب دلخواه بر اساس ID
$desired_order = [33, 65, 153,67,244,71,243,245,246];

// ۳. مرتب‌سازی با usort
usort($roots, function($a, $b) use ($desired_order) {
    $posA = array_search($a->term_id, $desired_order);
    $posB = array_search($b->term_id, $desired_order);
    // اگر ID در آرایه نبود، آن را در انتها قرار می‌دهیم
    $posA = ($posA === false) ? PHP_INT_MAX : $posA;
    $posB = ($posB === false) ? PHP_INT_MAX : $posB;
    return $posA - $posB;
});

    // ذخیره ریشه‌ها
    $tree[0] = array_map(function($term){
        return [
            'id'   => $term->term_id,
            'name' => $term->name,
            'url'  => get_term_link($term),
            'type' => 'category',
        ];
    }, $roots);
    // 2. صف برای پردازش بازگشتی همهٔ دسته‌ها
    $queue = wp_list_pluck($roots, 'term_id');
    while ( $queue ) {
        $parent_id = array_shift($queue);
        // ۲.۱ زیرشاخه‌های مستقیم
        $child_terms = get_terms([
            'taxonomy'        => $taxonomy,
            'hide_empty'      => false,
            'parent'          => $parent_id,
            'hierarchical'    => false,
        ]);
        // تبدیل به آرایهٔ مناسب
        $items = [];
        if ( ! is_wp_error($child_terms) && ! empty($child_terms) ) {
            // دسته‌ها را اول می‌آوریم
            foreach ( $child_terms as $c ) {
                $items[] = [
                    'id'   => $c->term_id,
                    'name' => $c->name,
                    'url'  => get_term_link($c),
                    'type' => 'category',
                ];
                // برای عمق‌های بعدی
                $queue[] = $c->term_id;
            }
        }
        // ۲.۲ محصولات مستقیمِ این دسته (include_children=false)
        $products = get_posts([
            'post_type'      => 'product',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'tax_query'      => [[
                'taxonomy'         => $taxonomy,
                'field'            => 'term_id',
                'terms'            => $parent_id,
                'include_children' => false,
            ]],
        ]);
        if ( ! empty($products) ) {
            foreach ( $products as $pid ) {
                $items[] = [
                    'id'    => $pid,
                    'name'  => get_the_title($pid),
                    'url'   => get_permalink($pid),
                    'type'  => 'product',
                ];
            }
        }
        // ۲.۳ ذخیره در نقشه
        $tree[ $parent_id ] = $items;
    }
    return $tree;
}

// کش کامل یک روزه
function cmenu_regenerate_tree() {
    $tree = cmenu_build_full_tree();
    set_transient('cmenu_tree', $tree, DAY_IN_SECONDS);
    return $tree;
}
add_action('save_post_product',  'cmenu_regenerate_tree');
add_action('edited_category',      'cmenu_regenerate_tree');
add_action('create_category',      'cmenu_regenerate_tree');
add_action('delete_category',      'cmenu_regenerate_tree');

/**
 * شورت‌کد [cmenu_ui] برای منوی جدید با ساختار UI/UX دلخواه
 */
add_shortcode('cmenu_ui', function() {
    // 1) بازخوانی درخت از ترنزینت
    $tree = get_transient('cmenu_tree');
    if ( false === $tree ) {
        $tree = cmenu_regenerate_tree();
    }
    $roots = $tree[0] ?? [];

    // 2) تعریف لینک‌های ثابت ریشه (غیرمحصولات)
    $static_links = [
 [
            'label' => 'خانه',
            'url'   => 'https://foladmarket.com/',
            'class' => 'home-link',
        ],
        [
            'label' => 'تماس با ما',
            'url'   => 'https://foladmarket.com/%d8%aa%d9%85%d8%a7%d8%b3-%d8%a8%d8%a7-%d9%85%d8%a7/',
            'class' => 'contact-link',
        ],
        [
            'label' => 'درباره ما',
            'url'   => 'https://foladmarket.com/%d8%af%d8%b1%d8%a8%d8%a7%d8%b1%d9%87-%d9%85%d8%a7/',
            'class' => 'about-link',
        ],
                [
            'label' => 'مقالات',
            'url'   => 'https://foladmarket.com/articles/blogs/',
            'class' => 'home-link',
        ],
                        [
            'label' => 'تامین کنندگان و کارخانه های فولاد',
            'url'   => 'https://foladmarket.com/articles/steel-suppliers/',
            'class' => 'home-link',
        ],
];

    ob_start(); ?>
    <nav class="cmenu-nav">
      <ul class="cmenu-root-menu">
        <!-- ۱. محصولات (ریشه با زیرمنو) -->
        <li class="cmenu-root-item cmenu-has-submenu products-link"   data-id="0" data-type="category">
          <span class="cmenu-root-label">محصولات</span>
          <ul class="cmenu-submenu">
            <?php foreach ( $roots as $item ) : ?>
              <li
                class="cmenu-submenu-item <?php echo $item['type'] === 'category' ? 'cmenu-subcategory' : 'cmenu-product'; ?>"
                data-id="<?php echo esc_attr($item['id']); ?>"
                data-type="<?php echo esc_attr($item['type']); ?>"
              >
                <a href="<?php echo esc_url($item['url']); ?>">
                  <?php echo esc_html($item['name']); ?>
                </a>
              </li>
            <?php endforeach; ?>
          </ul>
        </li>

        <!-- ۲. لینک‌های ثابت کنار محصولات -->
        <?php foreach ( $static_links as $link ) : ?>
          <li class="cmenu-root-item static-link <?php echo esc_attr($link['class']); ?>">
            <a class="cmenu-root-label" href="<?php echo esc_url($link['url']); ?>">
              <?php echo esc_html($link['label']); ?>
            </a>
          </li>
        <?php endforeach; ?>
      </ul>
    </nav>
    <!-- Inline JSON data -->
    <script id="cmenu-data" type="application/json">
    <?php echo wp_json_encode($tree, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?>
    </script>
    <?php
    return ob_get_clean();
});
add_action('wp_enqueue_scripts', function() {
    $dir = plugin_dir_path(__FILE__);
    $uri = plugin_dir_url(__FILE__);

    // JS
    $js = $dir . 'assets/js/menu-loader-inline.js';
    if ( file_exists($js) ) {
        wp_enqueue_script(
            'cmenu-inline-loader',
            $uri . 'assets/js/menu-loader-inline.js',
            [],
            filemtime($js),
            true
        );
    }

    // CSS
    $css = $dir . 'assets/css/cmenu-ui.css';
    if ( file_exists($css) ) {
        wp_enqueue_style(
            'cmenu-ui-style',
            $uri . 'assets/css/cmenu-ui.css',
            [],
            filemtime($css),
            'all'
        );
    }
});
